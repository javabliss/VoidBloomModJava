package com.voidbloom.menu;

import com.voidbloom.block.ResonanceForgeBlockEntity;
import com.voidbloom.registry.ModBlocks;
import com.voidbloom.registry.ModItems;
import com.voidbloom.registry.ModMenus;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class ResonanceForgeMenu extends AbstractContainerMenu {
    private final Container container;
    private final ContainerData data;
    private final ContainerLevelAccess access;

    /** Клиентский конструктор. */
    public ResonanceForgeMenu(int id, Inventory inv, RegistryFriendlyByteBuf buf) {
        this(id, inv, new SimpleContainer(ResonanceForgeBlockEntity.SLOTS), new SimpleContainerData(5),
                ContainerLevelAccess.create(inv.player.level(), buf.readBlockPos()));
    }

    public ResonanceForgeMenu(int id, Inventory inv, Container container, ContainerData data, ContainerLevelAccess access) {
        super(ModMenus.RESONANCE_FORGE.get(), id);
        this.container = container;
        this.data = data;
        this.access = access;
        checkContainerSize(container, ResonanceForgeBlockEntity.SLOTS);
        this.addSlot(new OreSlot(container, 0, 26, 17, ModItems.SCORCHITE_SHARD.get()));
        this.addSlot(new OreSlot(container, 1, 52, 17, ModItems.UMBRALITE_CHUNK.get()));
        this.addSlot(new OreSlot(container, 2, 78, 17, ModItems.LUMINA_GEM.get()));
        this.addSlot(new Slot(container, 3, 52, 53) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return ResonanceForgeBlockEntity.fuelValue(stack) > 0;
            }
        });
        this.addSlot(new Slot(container, 4, 136, 35) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return false;
            }
        });
        for (int row = 0; row < 3; row++)
            for (int col = 0; col < 9; col++)
                this.addSlot(new Slot(inv, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
        for (int col = 0; col < 9; col++) this.addSlot(new Slot(inv, col, 8 + col * 18, 142));
        this.addDataSlots(data);
    }

    private static class OreSlot extends Slot {
        private final Item allowed;

        OreSlot(Container c, int i, int x, int y, Item allowed) {
            super(c, i, x, y);
            this.allowed = allowed;
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return stack.is(allowed);
        }
    }

    public int progressScaled(int pixels) {
        int total = data.get(1);
        return total == 0 ? 0 : data.get(0) * pixels / total;
    }

    public int burnScaled(int pixels) {
        int total = data.get(3);
        return total == 0 ? 0 : Math.min(pixels, data.get(2) * pixels / total);
    }

    public boolean isValidStructure() {
        return data.get(4) != 0;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasItem()) return ItemStack.EMPTY;
        ItemStack stack = slot.getItem();
        ItemStack copy = stack.copy();
        if (index < ResonanceForgeBlockEntity.SLOTS) {
            if (!this.moveItemStackTo(stack, 5, 41, true)) return ItemStack.EMPTY;
        } else {
            boolean moved = false;
            if (stack.is(ModItems.SCORCHITE_SHARD.get())) moved = this.moveItemStackTo(stack, 0, 1, false);
            else if (stack.is(ModItems.UMBRALITE_CHUNK.get())) moved = this.moveItemStackTo(stack, 1, 2, false);
            else if (stack.is(ModItems.LUMINA_GEM.get())) moved = this.moveItemStackTo(stack, 2, 3, false);
            else if (ResonanceForgeBlockEntity.fuelValue(stack) > 0) moved = this.moveItemStackTo(stack, 3, 4, false);
            if (!moved) {
                moved = index < 32 ? this.moveItemStackTo(stack, 32, 41, false) : this.moveItemStackTo(stack, 5, 32, false);
                if (!moved) return ItemStack.EMPTY;
            }
        }
        if (stack.isEmpty()) slot.setByPlayer(ItemStack.EMPTY);
        else slot.setChanged();
        if (stack.getCount() == copy.getCount()) return ItemStack.EMPTY;
        slot.onTake(player, stack);
        return copy;
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, ModBlocks.RESONANCE_FORGE.get());
    }
}
