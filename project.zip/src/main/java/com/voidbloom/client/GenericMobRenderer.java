package com.voidbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.voidbloom.VoidbloomMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;

import java.util.function.Function;

/** Рендерер мобов мода: своя модель, текстура и светящийся слой (<имя>_glow.png). */
public class GenericMobRenderer<T extends Mob, M extends EntityModel<T>> extends MobRenderer<T, M> {
    private final ResourceLocation texture;
    private final float scale;

    public GenericMobRenderer(EntityRendererProvider.Context ctx, M model, float shadow, String name, float scale) {
        super(ctx, model, shadow);
        this.texture = VoidbloomMod.id("textures/entity/" + name + ".png");
        this.scale = scale;
        this.addLayer(new GlowLayer<>(this, VoidbloomMod.id("textures/entity/" + name + "_glow.png")));
    }

    public static <T extends Mob, M extends EntityModel<T>> EntityRendererProvider<T> of(
            Function<ModelPart, M> factory, ModelLayerLocation layer, float shadow, String name, float scale) {
        return ctx -> new GenericMobRenderer<T, M>(ctx, factory.apply(ctx.bakeLayer(layer)), shadow, name, scale);
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return texture;
    }

    @Override
    protected void scale(T entity, PoseStack stack, float partialTick) {
        stack.scale(scale, scale, scale);
    }

    static class GlowLayer<T extends Entity, M extends EntityModel<T>> extends EyesLayer<T, M> {
        private final RenderType type;

        GlowLayer(RenderLayerParent<T, M> parent, ResourceLocation glowTexture) {
            super(parent);
            this.type = RenderType.eyes(glowTexture);
        }

        @Override
        public RenderType renderType() {
            return type;
        }
    }
}
