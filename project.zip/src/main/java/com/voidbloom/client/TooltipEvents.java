package com.voidbloom.client;

import com.voidbloom.VoidbloomMod;
import net.minecraft.ChatFormatting;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;

/** Подсказки на предметах мода: ключ tooltip.voidbloom.<имя>. */
@EventBusSubscriber(modid = VoidbloomMod.MODID, value = Dist.CLIENT)
public class TooltipEvents {
    @SubscribeEvent
    public static void tooltip(ItemTooltipEvent event) {
        ResourceLocation id = BuiltInRegistries.ITEM.getKey(event.getItemStack().getItem());
        if (!id.getNamespace().equals(VoidbloomMod.MODID)) return;
        String path = id.getPath();
        if (path.matches("(echo|resonite)_(helmet|chestplate|leggings|boots)")) path = path.substring(0, path.indexOf('_')) + "_armor";
        String key = "tooltip.voidbloom." + path;
        if (I18n.exists(key)) event.getToolTip().add(Component.translatable(key).withStyle(ChatFormatting.GRAY));
    }
}
