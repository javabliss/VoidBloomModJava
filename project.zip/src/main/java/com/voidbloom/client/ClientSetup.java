package com.voidbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.voidbloom.VoidbloomMod;
import com.voidbloom.entity.EchoSovereignEntity;
import com.voidbloom.entity.GlowPuffEntity;
import com.voidbloom.entity.HollowStalkerEntity;
import com.voidbloom.entity.ShardlingEntity;
import com.voidbloom.registry.ModEntities;
import net.minecraft.client.model.EndermanModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PigModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = VoidbloomMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void registerSky(net.neoforged.neoforge.client.event.RegisterDimensionSpecialEffectsEvent event) {
        event.register(VoidbloomMod.id("echo_sky"), new EchoSkyEffects());
    }

    @SubscribeEvent
    public static void registerScreens(net.neoforged.neoforge.client.event.RegisterMenuScreensEvent event) {
        event.register(com.voidbloom.registry.ModMenus.RESONANCE_FORGE.get(), ResonanceForgeScreen::new);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.SHARDLING.get(), ShardlingRenderer::new);
        event.registerEntityRenderer(ModEntities.HOLLOW_STALKER.get(), StalkerRenderer::new);
        event.registerEntityRenderer(ModEntities.GLOW_PUFF.get(), PuffRenderer::new);
        event.registerEntityRenderer(ModEntities.ECHO_SOVEREIGN.get(), SovereignRenderer::new);
        event.registerEntityRenderer(ModEntities.ECHO_DRIFTER.get(), DrifterRenderer::new);
        event.registerEntityRenderer(ModEntities.ECHO_GUARDIAN.get(), GuardianRenderer::new);
        event.registerEntityRenderer(ModEntities.ECHO_VILLAGER.get(), EchoVillagerRenderer::new);
    }

    private static ResourceLocation tex(String name) {
        return VoidbloomMod.id("textures/entity/" + name + ".png");
    }

    static class ShardlingRenderer extends MobRenderer<ShardlingEntity, HumanoidModel<ShardlingEntity>> {
        ShardlingRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.ZOMBIE)), 0.4F);
        }

        @Override
        public ResourceLocation getTextureLocation(ShardlingEntity entity) {
            return tex("shardling");
        }

        @Override
        protected void scale(ShardlingEntity entity, PoseStack stack, float partialTick) {
            stack.scale(0.8F, 0.8F, 0.8F);
        }
    }

    static class StalkerRenderer extends MobRenderer<HollowStalkerEntity, EndermanModel<HollowStalkerEntity>> {
        StalkerRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new EndermanModel<>(ctx.bakeLayer(ModelLayers.ENDERMAN)), 0.5F);
        }

        @Override
        public ResourceLocation getTextureLocation(HollowStalkerEntity entity) {
            return tex("hollow_stalker");
        }
    }

    static class PuffRenderer extends MobRenderer<GlowPuffEntity, PigModel<GlowPuffEntity>> {
        PuffRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new PigModel<>(ctx.bakeLayer(ModelLayers.PIG)), 0.4F);
        }

        @Override
        public ResourceLocation getTextureLocation(GlowPuffEntity entity) {
            return tex("glow_puff");
        }
    }

    static class SovereignRenderer extends MobRenderer<EchoSovereignEntity, HumanoidModel<EchoSovereignEntity>> {
        SovereignRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.ZOMBIE)), 1.2F);
        }

        @Override
        public ResourceLocation getTextureLocation(EchoSovereignEntity entity) {
            return tex("echo_sovereign");
        }

        @Override
        protected void scale(EchoSovereignEntity entity, PoseStack stack, float partialTick) {
            stack.scale(2.2F, 2.2F, 2.2F);
        }
    }

    static class DrifterRenderer extends MobRenderer<com.voidbloom.entity.EchoDrifterEntity, net.minecraft.client.model.SquidModel<com.voidbloom.entity.EchoDrifterEntity>> {
        DrifterRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new net.minecraft.client.model.SquidModel<>(ctx.bakeLayer(ModelLayers.SQUID)), 0.3F);
        }

        @Override
        public ResourceLocation getTextureLocation(com.voidbloom.entity.EchoDrifterEntity entity) {
            return tex("echo_drifter");
        }

        @Override
        protected int getBlockLightLevel(com.voidbloom.entity.EchoDrifterEntity entity, net.minecraft.core.BlockPos pos) {
            return 15;
        }
    }

    static class GuardianRenderer extends MobRenderer<com.voidbloom.entity.EchoGuardianEntity, HumanoidModel<com.voidbloom.entity.EchoGuardianEntity>> {
        GuardianRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.ZOMBIE)), 0.8F);
        }

        @Override
        public ResourceLocation getTextureLocation(com.voidbloom.entity.EchoGuardianEntity entity) {
            return tex("echo_guardian");
        }

        @Override
        protected void scale(com.voidbloom.entity.EchoGuardianEntity entity, PoseStack stack, float partialTick) {
            stack.scale(1.35F, 1.35F, 1.35F);
        }
    }

    static class EchoVillagerRenderer extends net.minecraft.client.renderer.entity.VillagerRenderer {
        EchoVillagerRenderer(EntityRendererProvider.Context ctx) {
            super(ctx);
        }

        @Override
        public ResourceLocation getTextureLocation(net.minecraft.world.entity.npc.Villager villager) {
            return tex("echo_villager");
        }
    }
}
