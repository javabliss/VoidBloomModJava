package com.voidbloom.client;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.client.model.DrifterModel;
import com.voidbloom.client.model.GuardianModel;
import com.voidbloom.client.model.PuffModel;
import com.voidbloom.client.model.ShardlingModel;
import com.voidbloom.client.model.SovereignModel;
import com.voidbloom.client.model.StalkerModel;
import com.voidbloom.entity.EchoDrifterEntity;
import com.voidbloom.entity.EchoGuardianEntity;
import com.voidbloom.entity.EchoSovereignEntity;
import com.voidbloom.entity.GlowPuffEntity;
import com.voidbloom.entity.HollowStalkerEntity;
import com.voidbloom.entity.ShardlingEntity;
import com.voidbloom.registry.ModEntities;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = VoidbloomMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void registerSky(net.neoforged.neoforge.client.event.RegisterDimensionSpecialEffectsEvent event) {
        event.register(VoidbloomMod.id("echo_sky"), new EchoSkyEffects());
    }

    @SubscribeEvent
    public static void registerScreens(net.neoforged.neoforge.client.event.RegisterMenuScreensEvent event) {
        event.register(com.voidbloom.registry.ModMenus.RESONANCE_FORGE.get(), ResonanceForgeScreen::new);
    }

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(ShardlingModel.LAYER, ShardlingModel::createLayer);
        event.registerLayerDefinition(StalkerModel.LAYER, StalkerModel::createLayer);
        event.registerLayerDefinition(PuffModel.LAYER, PuffModel::createLayer);
        event.registerLayerDefinition(SovereignModel.LAYER, SovereignModel::createLayer);
        event.registerLayerDefinition(DrifterModel.LAYER, DrifterModel::createLayer);
        event.registerLayerDefinition(GuardianModel.LAYER, GuardianModel::createLayer);
    }

    private static ResourceLocation tex(String name) {
        return VoidbloomMod.id("textures/entity/" + name + ".png");
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.SHARDLING.get(), GenericMobRenderer.<ShardlingEntity, ShardlingModel<ShardlingEntity>>of(
                ShardlingModel::new, ShardlingModel.LAYER, 0.4F, "shardling", 1.15F));
        event.registerEntityRenderer(ModEntities.HOLLOW_STALKER.get(), GenericMobRenderer.<HollowStalkerEntity, StalkerModel<HollowStalkerEntity>>of(
                StalkerModel::new, StalkerModel.LAYER, 0.5F, "hollow_stalker", 1.15F));
        event.registerEntityRenderer(ModEntities.GLOW_PUFF.get(), GenericMobRenderer.<GlowPuffEntity, PuffModel<GlowPuffEntity>>of(
                PuffModel::new, PuffModel.LAYER, 0.5F, "glow_puff", 1.2F));
        event.registerEntityRenderer(ModEntities.ECHO_SOVEREIGN.get(), GenericMobRenderer.<EchoSovereignEntity, SovereignModel<EchoSovereignEntity>>of(
                SovereignModel::new, SovereignModel.LAYER, 1.2F, "echo_sovereign", 1.05F));
        event.registerEntityRenderer(ModEntities.ECHO_DRIFTER.get(), GenericMobRenderer.<EchoDrifterEntity, DrifterModel<EchoDrifterEntity>>of(
                DrifterModel::new, DrifterModel.LAYER, 0.3F, "echo_drifter", 1.0F));
        event.registerEntityRenderer(ModEntities.ECHO_GUARDIAN.get(), GenericMobRenderer.<EchoGuardianEntity, GuardianModel<EchoGuardianEntity>>of(
                GuardianModel::new, GuardianModel.LAYER, 0.8F, "echo_guardian", 1.35F));
        event.registerEntityRenderer(ModEntities.ECHO_VILLAGER.get(), EchoVillagerRenderer::new);
    }

    static class EchoVillagerRenderer extends net.minecraft.client.renderer.entity.VillagerRenderer {
        EchoVillagerRenderer(EntityRendererProvider.Context ctx) {
            super(ctx);
        }

        @Override
        public ResourceLocation getTextureLocation(net.minecraft.world.entity.npc.Villager villager) {
            return tex("echo_villager");
        }
    }
}
