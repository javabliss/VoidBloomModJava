package com.voidbloom.client;

import com.voidbloom.net.GatePayloads;
import net.minecraft.client.Minecraft;

/** Клиентские обработчики пакетов (класс грузится только на клиенте). */
public class ClientHooks {
    public static void openGateScreen(GatePayloads.Open payload) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof WaypointScreen screen) screen.update(payload);
        else mc.setScreen(new WaypointScreen(payload));
    }
}
