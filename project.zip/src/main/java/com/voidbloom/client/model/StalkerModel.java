package com.voidbloom.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.voidbloom.VoidbloomMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;

/** Сгенерировано gen_v7d.py: модель «hollow_stalker». */
public class StalkerModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(VoidbloomMod.id("hollow_stalker"), "main");
    private final ModelPart root;
    private final ModelPart p_legR;
    private final ModelPart p_legL;
    private final ModelPart p_torso;
    private final ModelPart p_head;
    private final ModelPart p_antL;
    private final ModelPart p_antR;
    private final ModelPart p_armL;
    private final ModelPart p_clawL;
    private final ModelPart p_armR;
    private final ModelPart p_clawR;
    private final ModelPart p_sp0;
    private final ModelPart p_sp1;
    private final ModelPart p_sp2;
    private final ModelPart p_sp3;

    public StalkerModel(ModelPart root) {
        this.root = root;
        this.p_legR = root.getChild("legR");
        this.p_legL = root.getChild("legL");
        this.p_torso = root.getChild("torso");
        this.p_head = root.getChild("torso").getChild("head");
        this.p_antL = root.getChild("torso").getChild("head").getChild("antL");
        this.p_antR = root.getChild("torso").getChild("head").getChild("antR");
        this.p_armL = root.getChild("torso").getChild("armL");
        this.p_clawL = root.getChild("torso").getChild("armL").getChild("clawL");
        this.p_armR = root.getChild("torso").getChild("armR");
        this.p_clawR = root.getChild("torso").getChild("armR").getChild("clawR");
        this.p_sp0 = root.getChild("torso").getChild("sp0");
        this.p_sp1 = root.getChild("torso").getChild("sp1");
        this.p_sp2 = root.getChild("torso").getChild("sp2");
        this.p_sp3 = root.getChild("torso").getChild("sp3");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition d_legR = root.addOrReplaceChild("legR", CubeListBuilder.create().texOffs(0, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 22.0F, 2.0F), PartPose.offsetAndRotation(-1.5F, 2.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_legL = root.addOrReplaceChild("legL", CubeListBuilder.create().texOffs(8, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 22.0F, 2.0F), PartPose.offsetAndRotation(1.5F, 2.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_torso = root.addOrReplaceChild("torso", CubeListBuilder.create().texOffs(32, 0).addBox(-3.0F, -12.0F, -1.5F, 6.0F, 12.0F, 3.0F), PartPose.offsetAndRotation(0.0F, 2.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_head = d_torso.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 24).addBox(-3.0F, -6.0F, -3.0F, 6.0F, 6.0F, 6.0F), PartPose.offsetAndRotation(0.0F, -12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_antL = d_head.addOrReplaceChild("antL", CubeListBuilder.create().texOffs(24, 24).addBox(-0.5F, -8.0F, -0.5F, 1.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(2.0F, -6.0F, 0.0F, 0.0F, 0.0F, 0.5F));
        PartDefinition d_antR = d_head.addOrReplaceChild("antR", CubeListBuilder.create().texOffs(28, 24).addBox(-0.5F, -8.0F, -0.5F, 1.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(-2.0F, -6.0F, 0.0F, 0.0F, 0.0F, -0.5F));
        PartDefinition d_armL = d_torso.addOrReplaceChild("armL", CubeListBuilder.create().texOffs(16, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 20.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -10.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_clawL = d_armL.addOrReplaceChild("clawL", CubeListBuilder.create().texOffs(32, 24).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 4.0F, 3.0F), PartPose.offsetAndRotation(0.0F, 20.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_armR = d_torso.addOrReplaceChild("armR", CubeListBuilder.create().texOffs(24, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 20.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -10.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_clawR = d_armR.addOrReplaceChild("clawR", CubeListBuilder.create().texOffs(44, 24).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 4.0F, 3.0F), PartPose.offsetAndRotation(0.0F, 20.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_sp0 = d_torso.addOrReplaceChild("sp0", CubeListBuilder.create().texOffs(0, 36).addBox(-1.0F, -1.5F, 0.0F, 2.0F, 3.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -11.0F, 1.8F, 0.3F, 0.0F, 0.0F));
        PartDefinition d_sp1 = d_torso.addOrReplaceChild("sp1", CubeListBuilder.create().texOffs(10, 36).addBox(-1.0F, -1.5F, 0.0F, 2.0F, 3.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -8.0F, 1.8F, 0.3F, 0.0F, 0.0F));
        PartDefinition d_sp2 = d_torso.addOrReplaceChild("sp2", CubeListBuilder.create().texOffs(20, 36).addBox(-1.0F, -1.5F, 0.0F, 2.0F, 3.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -5.0F, 1.8F, 0.3F, 0.0F, 0.0F));
        PartDefinition d_sp3 = d_torso.addOrReplaceChild("sp3", CubeListBuilder.create().texOffs(30, 36).addBox(-1.0F, -1.5F, 0.0F, 2.0F, 3.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -2.0F, 1.8F, 0.3F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch) {
        boolean aggro = entity instanceof Mob m && m.isAggressive();
        float t = age;
        p_head.yRot = yaw * 0.017453292F;
        p_head.xRot = pitch * 0.017453292F;
        float sw = Mth.cos(limbSwing * 0.6662F) * 1.0F * limbSwingAmount;
        p_legR.xRot = sw;
        p_legL.xRot = -sw;
        p_armR.xRot = -sw * 0.8F + (aggro ? -0.9F : 0.0F);
        p_armL.xRot = sw * 0.8F + (aggro ? -0.9F : 0.0F);
        p_armR.zRot = 0.08F + Mth.sin(t * 0.06F) * 0.04F;
        p_armL.zRot = -0.08F - Mth.sin(t * 0.06F) * 0.04F;
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, int color) {
        root.render(ps, vc, light, overlay, color);
    }
}
