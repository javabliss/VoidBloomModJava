package com.voidbloom.item;

import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;

/** Эхо-якорь: Shift+ПКМ запоминает точку, ПКМ возвращает к ней (даже между измерениями). */
public class EchoAnchorItem extends Item {
    public EchoAnchorItem(Properties properties) {
        super(properties);
    }

    private static CompoundTag data(ItemStack stack) {
        return stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return data(stack).contains("dim");
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer sp)) return InteractionResultHolder.sidedSuccess(stack, true);
        CompoundTag tag = data(stack);
        if (player.isShiftKeyDown()) {
            tag.putString("dim", level.dimension().location().toString());
            tag.putDouble("x", player.getX());
            tag.putDouble("y", player.getY());
            tag.putDouble("z", player.getZ());
            tag.putFloat("yaw", player.getYRot());
            stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
            ((ServerLevel) level).sendParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1.0D, player.getZ(), 30, 0.4D, 0.8D, 0.4D, 0.02D);
            level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.5F, 1.2F);
            player.displayClientMessage(Component.translatable("message.voidbloom.anchor_set"), true);
            return InteractionResultHolder.success(stack);
        }
        if (!tag.contains("dim")) {
            player.displayClientMessage(Component.translatable("message.voidbloom.anchor_empty"), true);
            return InteractionResultHolder.fail(stack);
        }
        ResourceKey<Level> key = ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(tag.getString("dim")));
        ServerLevel dest = ((ServerLevel) level).getServer().getLevel(key);
        if (dest == null) return InteractionResultHolder.fail(stack);
        ((ServerLevel) level).sendParticles(ParticleTypes.PORTAL, player.getX(), player.getY() + 1.0D, player.getZ(), 40, 0.4D, 0.8D, 0.4D, 0.2D);
        sp.teleportTo(dest, tag.getDouble("x"), tag.getDouble("y"), tag.getDouble("z"), tag.getFloat("yaw"), 0.0F);
        dest.playSound(null, sp.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.0F);
        stack.hurtAndBreak(1, sp, LivingEntity.getSlotForHand(hand));
        player.getCooldowns().addCooldown(this, 100);
        return InteractionResultHolder.success(stack);
    }
}
