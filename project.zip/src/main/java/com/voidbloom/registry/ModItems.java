package com.voidbloom.registry;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.item.RiftWandItem;
import com.voidbloom.item.ElixirItem;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(VoidbloomMod.MODID);

    public static final DeferredItem<Item> ECHO_CRYSTAL = ITEMS.registerSimpleItem("echo_crystal");

    // --- Инструменты ---
    public static final DeferredItem<SwordItem> ECHO_SWORD = ITEMS.register("echo_sword",
            () -> new SwordItem(ModTiers.ECHO, new Item.Properties()
                    .attributes(SwordItem.createAttributes(ModTiers.ECHO, 3, -2.4F))));
    public static final DeferredItem<PickaxeItem> ECHO_PICKAXE = ITEMS.register("echo_pickaxe",
            () -> new PickaxeItem(ModTiers.ECHO, new Item.Properties()
                    .attributes(PickaxeItem.createAttributes(ModTiers.ECHO, 1.0F, -2.8F))));
    public static final DeferredItem<AxeItem> ECHO_AXE = ITEMS.register("echo_axe",
            () -> new AxeItem(ModTiers.ECHO, new Item.Properties()
                    .attributes(AxeItem.createAttributes(ModTiers.ECHO, 5.0F, -3.0F))));
    public static final DeferredItem<ShovelItem> ECHO_SHOVEL = ITEMS.register("echo_shovel",
            () -> new ShovelItem(ModTiers.ECHO, new Item.Properties()
                    .attributes(ShovelItem.createAttributes(ModTiers.ECHO, 1.5F, -3.0F))));
    public static final DeferredItem<HoeItem> ECHO_HOE = ITEMS.register("echo_hoe",
            () -> new HoeItem(ModTiers.ECHO, new Item.Properties()
                    .attributes(HoeItem.createAttributes(ModTiers.ECHO, -2.0F, -0.5F))));

    // --- Броня ---
    public static final DeferredItem<ArmorItem> ECHO_HELMET = ITEMS.register("echo_helmet",
            () -> new ArmorItem(ModArmor.ECHO, ArmorItem.Type.HELMET,
                    new Item.Properties().durability(ArmorItem.Type.HELMET.getDurability(38))));
    public static final DeferredItem<ArmorItem> ECHO_CHESTPLATE = ITEMS.register("echo_chestplate",
            () -> new ArmorItem(ModArmor.ECHO, ArmorItem.Type.CHESTPLATE,
                    new Item.Properties().durability(ArmorItem.Type.CHESTPLATE.getDurability(38))));
    public static final DeferredItem<ArmorItem> ECHO_LEGGINGS = ITEMS.register("echo_leggings",
            () -> new ArmorItem(ModArmor.ECHO, ArmorItem.Type.LEGGINGS,
                    new Item.Properties().durability(ArmorItem.Type.LEGGINGS.getDurability(38))));
    public static final DeferredItem<ArmorItem> ECHO_BOOTS = ITEMS.register("echo_boots",
            () -> new ArmorItem(ModArmor.ECHO, ArmorItem.Type.BOOTS,
                    new Item.Properties().durability(ArmorItem.Type.BOOTS.getDurability(38))));

    // --- Уникальный предмет (падает только с босса) ---
    public static final DeferredItem<RiftWandItem> RIFT_WAND = ITEMS.register("rift_wand",
            () -> new RiftWandItem(new Item.Properties().stacksTo(1).durability(320).rarity(Rarity.EPIC)));


    // --- Еда ---
    public static final DeferredItem<Item> BLOOM_FRUIT = ITEMS.register("bloom_fruit",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(4).saturationModifier(0.4F).build())));
    public static final DeferredItem<Item> CANDIED_SHARD = ITEMS.register("candied_shard",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.3F).alwaysEdible()
                    .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 400, 1), 1.0F).build())));
    public static final DeferredItem<Item> ECHO_PIE = ITEMS.register("echo_pie",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(8).saturationModifier(0.8F)
                    .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 120, 0), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 1200, 0), 1.0F).build())));
    public static final DeferredItem<Item> RAW_PUFFMEAT = ITEMS.register("raw_puffmeat",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.2F).build())));
    public static final DeferredItem<Item> COOKED_PUFFMEAT = ITEMS.register("cooked_puffmeat",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(7).saturationModifier(0.7F).build())));
    public static final DeferredItem<BlockItem> ECHO_DOOR = ITEMS.register("echo_door",
            () -> new BlockItem(ModBlocks.ECHO_DOOR.get(), new Item.Properties()));


    // --- Руды трёх миров и резонит ---
    public static final DeferredItem<Item> SCORCHITE_SHARD = ITEMS.registerSimpleItem("scorchite_shard", new Item.Properties().fireResistant());
    public static final DeferredItem<Item> UMBRALITE_CHUNK = ITEMS.registerSimpleItem("umbralite_chunk");
    public static final DeferredItem<Item> LUMINA_GEM = ITEMS.registerSimpleItem("lumina_gem");
    public static final DeferredItem<Item> RESONITE_INGOT = ITEMS.registerSimpleItem("resonite_ingot", new Item.Properties().fireResistant().rarity(Rarity.RARE));
    public static final DeferredItem<Item> RESONITE_TEMPLATE = ITEMS.registerSimpleItem("resonite_upgrade_smithing_template", new Item.Properties().rarity(Rarity.RARE));

    public static final DeferredItem<SwordItem> RESONITE_SWORD = ITEMS.register("resonite_sword",
            () -> new SwordItem(ModTiers.RESONITE, new Item.Properties().fireResistant()
                    .attributes(SwordItem.createAttributes(ModTiers.RESONITE, 3, -2.4F))));
    public static final DeferredItem<PickaxeItem> RESONITE_PICKAXE = ITEMS.register("resonite_pickaxe",
            () -> new PickaxeItem(ModTiers.RESONITE, new Item.Properties().fireResistant()
                    .attributes(PickaxeItem.createAttributes(ModTiers.RESONITE, 1.0F, -2.8F))));
    public static final DeferredItem<AxeItem> RESONITE_AXE = ITEMS.register("resonite_axe",
            () -> new AxeItem(ModTiers.RESONITE, new Item.Properties().fireResistant()
                    .attributes(AxeItem.createAttributes(ModTiers.RESONITE, 5.0F, -3.0F))));
    public static final DeferredItem<ShovelItem> RESONITE_SHOVEL = ITEMS.register("resonite_shovel",
            () -> new ShovelItem(ModTiers.RESONITE, new Item.Properties().fireResistant()
                    .attributes(ShovelItem.createAttributes(ModTiers.RESONITE, 1.5F, -3.0F))));
    public static final DeferredItem<HoeItem> RESONITE_HOE = ITEMS.register("resonite_hoe",
            () -> new HoeItem(ModTiers.RESONITE, new Item.Properties().fireResistant()
                    .attributes(HoeItem.createAttributes(ModTiers.RESONITE, -4.0F, 0.0F))));
    public static final DeferredItem<ArmorItem> RESONITE_HELMET = ITEMS.register("resonite_helmet",
            () -> new ArmorItem(ModArmor.RESONITE, ArmorItem.Type.HELMET,
                    new Item.Properties().fireResistant().durability(ArmorItem.Type.HELMET.getDurability(46))));
    public static final DeferredItem<ArmorItem> RESONITE_CHESTPLATE = ITEMS.register("resonite_chestplate",
            () -> new ArmorItem(ModArmor.RESONITE, ArmorItem.Type.CHESTPLATE,
                    new Item.Properties().fireResistant().durability(ArmorItem.Type.CHESTPLATE.getDurability(46))));
    public static final DeferredItem<ArmorItem> RESONITE_LEGGINGS = ITEMS.register("resonite_leggings",
            () -> new ArmorItem(ModArmor.RESONITE, ArmorItem.Type.LEGGINGS,
                    new Item.Properties().fireResistant().durability(ArmorItem.Type.LEGGINGS.getDurability(46))));
    public static final DeferredItem<ArmorItem> RESONITE_BOOTS = ITEMS.register("resonite_boots",
            () -> new ArmorItem(ModArmor.RESONITE, ArmorItem.Type.BOOTS,
                    new Item.Properties().fireResistant().durability(ArmorItem.Type.BOOTS.getDurability(46))));

    public static final DeferredItem<Item> STARDUST = ITEMS.registerSimpleItem("stardust");

    public static final DeferredItem<Item> ECHO_BLOOM_SEEDS = ITEMS.register("echo_bloom_seeds",
            () -> new ItemNameBlockItem(ModBlocks.ECHO_BLOOM.get(), new Item.Properties()));
    public static final DeferredItem<Item> ECHO_BLOOM_FLOWER = ITEMS.register("echo_bloom_flower",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.3F).fast().build())));
    public static final DeferredItem<ElixirItem> ELIXIR_SIGHT = ITEMS.register("elixir_sight",
            () -> new ElixirItem(new Item.Properties().stacksTo(16).food(new FoodProperties.Builder().nutrition(0).saturationModifier(0.0F).alwaysEdible()
                    .effect(() -> new MobEffectInstance(MobEffects.NIGHT_VISION, 6000, 0), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.GLOWING, 1200, 0), 1.0F).build())));
    public static final DeferredItem<ElixirItem> ELIXIR_STARSTEP = ITEMS.register("elixir_starstep",
            () -> new ElixirItem(new Item.Properties().stacksTo(16).food(new FoodProperties.Builder().nutrition(0).saturationModifier(0.0F).alwaysEdible()
                    .effect(() -> new MobEffectInstance(MobEffects.JUMP, 3600, 2), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.SLOW_FALLING, 3600, 0), 1.0F).build())));
    public static final DeferredItem<ElixirItem> ELIXIR_RESONANCE = ITEMS.register("elixir_resonance",
            () -> new ElixirItem(new Item.Properties().stacksTo(16).food(new FoodProperties.Builder().nutrition(0).saturationModifier(0.0F).alwaysEdible()
                    .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 3600, 1), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 3600, 2), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 200, 1), 1.0F).build())));
    public static final DeferredItem<DeferredSpawnEggItem> ECHO_DRIFTER_SPAWN_EGG = ITEMS.register("echo_drifter_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.ECHO_DRIFTER, 0xFF8FC3, 0x7FF0E6, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> ECHO_GUARDIAN_SPAWN_EGG = ITEMS.register("echo_guardian_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.ECHO_GUARDIAN, 0x2F2A4C, 0x7FF0E6, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> ECHO_VILLAGER_SPAWN_EGG = ITEMS.register("echo_villager_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.ECHO_VILLAGER, 0xB88CF0, 0xFF8FC3, new Item.Properties()));

    // --- Яйца призыва ---
    public static final DeferredItem<DeferredSpawnEggItem> SHARDLING_SPAWN_EGG = ITEMS.register("shardling_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.SHARDLING, 0x6B3FA0, 0xD9B8FF, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> HOLLOW_STALKER_SPAWN_EGG = ITEMS.register("hollow_stalker_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.HOLLOW_STALKER, 0x14081F, 0xFF3FD0, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> GLOW_PUFF_SPAWN_EGG = ITEMS.register("glow_puff_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.GLOW_PUFF, 0x5AF0E6, 0xFFF59A, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> ECHO_SOVEREIGN_SPAWN_EGG = ITEMS.register("echo_sovereign_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.ECHO_SOVEREIGN, 0x2A0A3F, 0xC77DFF, new Item.Properties()));
}
