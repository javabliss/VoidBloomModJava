package com.voidbloom.registry;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.block.ArenaCoreBlock;
import com.voidbloom.block.EchoBloomCropBlock;
import com.voidbloom.block.EchoGateBlock;
import com.voidbloom.block.ResonanceForgeBlock;
import com.voidbloom.block.RiftPortalBlock;
import com.voidbloom.block.SovereignAltarBlock;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(VoidbloomMod.MODID);

    public static final DeferredBlock<Block> ECHO_STONE = registerWithItem("echo_stone",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE)
                    .strength(2.0F, 6.0F).requiresCorrectToolForDrops().sound(SoundType.DEEPSLATE)));

    public static final DeferredBlock<Block> ECHO_SOIL = registerWithItem("echo_soil",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLUE)
                    .strength(0.8F).sound(SoundType.MOSS)));

    public static final DeferredBlock<Block> ECHO_CRYSTAL_ORE = registerWithItem("echo_crystal_ore",
            () -> new DropExperienceBlock(UniformInt.of(3, 7), BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PURPLE).strength(3.5F, 4.0F).requiresCorrectToolForDrops()
                    .lightLevel(s -> 5).sound(SoundType.AMETHYST)));

    public static final DeferredBlock<Block> ECHO_CRYSTAL_BLOCK = registerWithItem("echo_crystal_block",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE)
                    .strength(5.0F, 8.0F).requiresCorrectToolForDrops()
                    .lightLevel(s -> 9).sound(SoundType.AMETHYST)));

    public static final DeferredBlock<Block> RIFT_FRAME = registerWithItem("rift_frame",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK)
                    .strength(30.0F, 1200.0F).requiresCorrectToolForDrops()
                    .lightLevel(s -> 4).sound(SoundType.DEEPSLATE_BRICKS)));

    public static final DeferredBlock<RiftPortalBlock> RIFT_PORTAL = BLOCKS.register("rift_portal",
            () -> new RiftPortalBlock(BlockBehaviour.Properties.of().noCollission().noLootTable()
                    .strength(-1.0F).lightLevel(s -> 11).sound(SoundType.GLASS)
                    .pushReaction(net.minecraft.world.level.material.PushReaction.BLOCK)));

    public static final DeferredBlock<RotatedPillarBlock> VOID_LOG = registerWithItem("void_log",
            () -> new RotatedPillarBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK)
                    .strength(2.0F).sound(SoundType.WOOD).ignitedByLava()));

    public static final DeferredBlock<LeavesBlock> VOID_LEAVES = registerWithItem("void_leaves",
            () -> new LeavesBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_MAGENTA)
                    .strength(0.2F).randomTicks().noOcclusion().lightLevel(s -> 6)
                    .sound(SoundType.AZALEA_LEAVES)
                    .isValidSpawn((state, level, pos, type) -> false)
                    .isSuffocating((s, l, p) -> false).isViewBlocking((s, l, p) -> false)));

    public static final DeferredBlock<SovereignAltarBlock> SOVEREIGN_ALTAR = registerWithItem("sovereign_altar",
            () -> new SovereignAltarBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE)
                    .strength(50.0F, 1200.0F).requiresCorrectToolForDrops()
                    .lightLevel(s -> 12).sound(SoundType.AMETHYST)));


    private static BlockBehaviour.Properties wood() {
        return BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PINK).strength(2.0F, 3.0F).sound(SoundType.CHERRY_WOOD).ignitedByLava();
    }
    public static final DeferredBlock<Block> ECHO_MOSS = registerWithItem("echo_moss",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_CYAN).strength(0.8F).sound(SoundType.MOSS)));
    public static final DeferredBlock<Block> ECHO_BRICKS = registerWithItem("echo_bricks",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(2.0F, 6.0F)
                    .requiresCorrectToolForDrops().sound(SoundType.DEEPSLATE_BRICKS)));
    public static final DeferredBlock<Block> ECHO_PLANKS = registerWithItem("echo_planks", () -> new Block(wood()));
    public static final DeferredBlock<StairBlock> ECHO_STAIRS = registerWithItem("echo_stairs",
            () -> new StairBlock(ECHO_PLANKS.get().defaultBlockState(), wood()));
    public static final DeferredBlock<SlabBlock> ECHO_SLAB = registerWithItem("echo_slab", () -> new SlabBlock(wood()));
    public static final DeferredBlock<FenceBlock> ECHO_FENCE = registerWithItem("echo_fence", () -> new FenceBlock(wood()));
    public static final DeferredBlock<FenceGateBlock> ECHO_FENCE_GATE = registerWithItem("echo_fence_gate",
            () -> new FenceGateBlock(WoodType.CHERRY, wood()));
    public static final DeferredBlock<DoorBlock> ECHO_DOOR = BLOCKS.register("echo_door",
            () -> new DoorBlock(BlockSetType.CHERRY, wood().noOcclusion()));
    public static final DeferredBlock<TrapDoorBlock> ECHO_TRAPDOOR = registerWithItem("echo_trapdoor",
            () -> new TrapDoorBlock(BlockSetType.CHERRY, wood().noOcclusion()));
    public static final DeferredBlock<ButtonBlock> ECHO_BUTTON = registerWithItem("echo_button",
            () -> new ButtonBlock(BlockSetType.CHERRY, 30, wood().noCollission().strength(0.5F)));
    public static final DeferredBlock<PressurePlateBlock> ECHO_PRESSURE_PLATE = registerWithItem("echo_pressure_plate",
            () -> new PressurePlateBlock(BlockSetType.CHERRY, wood().noCollission().strength(0.5F)));

    private static BlockBehaviour.Properties ore(MapColor c, int light, SoundType snd) {
        return BlockBehaviour.Properties.of().mapColor(c).strength(4.5F, 6.0F).requiresCorrectToolForDrops().lightLevel(s -> light).sound(snd);
    }
    public static final DeferredBlock<Block> SCORCHITE_ORE = registerWithItem("scorchite_ore",
            () -> new DropExperienceBlock(UniformInt.of(4, 8), ore(MapColor.NETHER, 7, SoundType.NETHER_ORE)));
    public static final DeferredBlock<Block> UMBRALITE_ORE = registerWithItem("umbralite_ore",
            () -> new DropExperienceBlock(UniformInt.of(4, 8), ore(MapColor.SAND, 5, SoundType.STONE)));
    public static final DeferredBlock<Block> LUMINA_ORE = registerWithItem("lumina_ore",
            () -> new DropExperienceBlock(UniformInt.of(3, 7), ore(MapColor.GOLD, 9, SoundType.AMETHYST)));
    public static final DeferredBlock<Block> RESONITE_BLOCK = registerWithItem("resonite_block",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(50.0F, 1200.0F)
                    .requiresCorrectToolForDrops().lightLevel(s -> 6).sound(SoundType.NETHERITE_BLOCK)));
    public static final DeferredBlock<ResonanceForgeBlock> RESONANCE_FORGE = registerWithItem("resonance_forge",
            () -> new ResonanceForgeBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(10.0F, 600.0F)
                    .requiresCorrectToolForDrops().lightLevel(s -> 8).sound(SoundType.DEEPSLATE_BRICKS)));

    public static final DeferredBlock<Block> ECHO_JELLY = registerWithItem("echo_jelly",
            () -> new SlimeBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PINK).friction(0.8F)
                    .sound(SoundType.SLIME_BLOCK).noOcclusion()));
    public static final DeferredBlock<Block> ECHO_LAMP = registerWithItem("echo_lamp",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PINK).strength(0.5F)
                    .lightLevel(s -> 15).sound(SoundType.GLASS)));
    public static final DeferredBlock<Block> ECHO_GLASS = registerWithItem("echo_glass",
            () -> new StainedGlassBlock(net.minecraft.world.item.DyeColor.CYAN, BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_CYAN).strength(0.3F)
                    .sound(SoundType.GLASS).noOcclusion().isValidSpawn((st, l, p, t) -> false)
                    .isRedstoneConductor((st, l, p) -> false).isSuffocating((st, l, p) -> false).isViewBlocking((st, l, p) -> false)));

    public static final DeferredBlock<ArenaCoreBlock> ARENA_CORE = registerWithItem("arena_core",
            () -> new ArenaCoreBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(-1.0F, 3600000.0F)
                    .lightLevel(s -> 10).sound(SoundType.DEEPSLATE_BRICKS).noLootTable()));
    public static final DeferredBlock<EchoGateBlock> ECHO_GATE = registerWithItem("echo_gate",
            () -> new EchoGateBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(3.0F, 8.0F)
                    .lightLevel(s -> 9).sound(SoundType.AMETHYST).noOcclusion()));
    public static final DeferredBlock<EchoBloomCropBlock> ECHO_BLOOM = BLOCKS.register("echo_bloom",
            () -> new EchoBloomCropBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PINK).noCollission().randomTicks()
                    .instabreak().sound(SoundType.CROP).pushReaction(net.minecraft.world.level.material.PushReaction.DESTROY).lightLevel(s -> 4)));

    private static <T extends Block> DeferredBlock<T> registerWithItem(String name, Supplier<T> block) {
        DeferredBlock<T> result = BLOCKS.register(name, block);
        ModItems.ITEMS.register(name, () -> new BlockItem(result.get(), new Item.Properties()));
        return result;
    }
}
