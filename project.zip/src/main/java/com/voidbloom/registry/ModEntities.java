package com.voidbloom.registry;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.entity.EchoDrifterEntity;
import com.voidbloom.entity.EchoGuardianEntity;
import com.voidbloom.entity.EchoSovereignEntity;
import com.voidbloom.entity.EchoVillagerEntity;
import com.voidbloom.entity.GlowPuffEntity;
import com.voidbloom.entity.HollowStalkerEntity;
import com.voidbloom.entity.ShardlingEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, VoidbloomMod.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<ShardlingEntity>> SHARDLING =
            ENTITIES.register("shardling", () -> EntityType.Builder
                    .of(ShardlingEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.7F).clientTrackingRange(8)
                    .build("shardling"));

    public static final DeferredHolder<EntityType<?>, EntityType<HollowStalkerEntity>> HOLLOW_STALKER =
            ENTITIES.register("hollow_stalker", () -> EntityType.Builder
                    .of(HollowStalkerEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 2.9F).clientTrackingRange(10)
                    .build("hollow_stalker"));

    public static final DeferredHolder<EntityType<?>, EntityType<GlowPuffEntity>> GLOW_PUFF =
            ENTITIES.register("glow_puff", () -> EntityType.Builder
                    .of(GlowPuffEntity::new, MobCategory.CREATURE)
                    .sized(0.9F, 0.9F).clientTrackingRange(8)
                    .build("glow_puff"));

    public static final DeferredHolder<EntityType<?>, EntityType<EchoSovereignEntity>> ECHO_SOVEREIGN =
            ENTITIES.register("echo_sovereign", () -> EntityType.Builder
                    .of(EchoSovereignEntity::new, MobCategory.MONSTER)
                    .sized(1.4F, 4.4F).fireImmune().clientTrackingRange(12)
                    .build("echo_sovereign"));

    public static final DeferredHolder<EntityType<?>, EntityType<EchoDrifterEntity>> ECHO_DRIFTER =
            ENTITIES.register("echo_drifter", () -> EntityType.Builder
                    .of(EchoDrifterEntity::new, MobCategory.CREATURE)
                    .sized(0.8F, 0.8F).clientTrackingRange(8)
                    .build("echo_drifter"));

    public static final DeferredHolder<EntityType<?>, EntityType<EchoGuardianEntity>> ECHO_GUARDIAN =
            ENTITIES.register("echo_guardian", () -> EntityType.Builder
                    .of(EchoGuardianEntity::new, MobCategory.MONSTER)
                    .sized(0.9F, 2.6F).fireImmune().clientTrackingRange(10)
                    .build("echo_guardian"));

    public static final DeferredHolder<EntityType<?>, EntityType<EchoVillagerEntity>> ECHO_VILLAGER =
            ENTITIES.register("echo_villager", () -> EntityType.Builder
                    .of(EchoVillagerEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.95F).clientTrackingRange(10)
                    .build("echo_villager"));
}
