package com.voidbloom.registry;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.block.ResonanceForgeBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, VoidbloomMod.MODID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ResonanceForgeBlockEntity>> RESONANCE_FORGE =
            BLOCK_ENTITIES.register("resonance_forge", () ->
                    BlockEntityType.Builder.of(ResonanceForgeBlockEntity::new, ModBlocks.RESONANCE_FORGE.get()).build(null));
}
