package com.voidbloom.registry;

import com.voidbloom.VoidbloomMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, VoidbloomMod.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.voidbloom"))
                    .icon(() -> new ItemStack(ModItems.ECHO_CRYSTAL.get()))
                    .displayItems((params, out) -> {
                        // Блоки
                        out.accept(ModBlocks.ECHO_STONE.get());
                        out.accept(ModBlocks.ECHO_SOIL.get());
                        out.accept(ModBlocks.ECHO_CRYSTAL_ORE.get());
                        out.accept(ModBlocks.ECHO_CRYSTAL_BLOCK.get());
                        out.accept(ModBlocks.RIFT_FRAME.get());
                        out.accept(ModBlocks.VOID_LOG.get());
                        out.accept(ModBlocks.VOID_LEAVES.get());
                        out.accept(ModBlocks.SOVEREIGN_ALTAR.get());
                        out.accept(ModBlocks.ECHO_MOSS.get());
                        out.accept(ModBlocks.ECHO_BRICKS.get());
                        out.accept(ModBlocks.ECHO_PLANKS.get());
                        out.accept(ModBlocks.ECHO_STAIRS.get());
                        out.accept(ModBlocks.ECHO_SLAB.get());
                        out.accept(ModBlocks.ECHO_FENCE.get());
                        out.accept(ModBlocks.ECHO_FENCE_GATE.get());
                        out.accept(ModItems.ECHO_DOOR.get());
                        out.accept(ModBlocks.ECHO_TRAPDOOR.get());
                        out.accept(ModBlocks.ECHO_BUTTON.get());
                        out.accept(ModBlocks.ECHO_PRESSURE_PLATE.get());
                        out.accept(ModItems.BLOOM_FRUIT.get());
                        out.accept(ModItems.CANDIED_SHARD.get());
                        out.accept(ModItems.ECHO_PIE.get());
                        out.accept(ModItems.RAW_PUFFMEAT.get());
                        out.accept(ModItems.COOKED_PUFFMEAT.get());
                        // Материалы, инструменты, броня
                        out.accept(ModItems.ECHO_CRYSTAL.get());
                        out.accept(ModItems.ECHO_SWORD.get());
                        out.accept(ModItems.ECHO_PICKAXE.get());
                        out.accept(ModItems.ECHO_AXE.get());
                        out.accept(ModItems.ECHO_SHOVEL.get());
                        out.accept(ModItems.ECHO_HOE.get());
                        out.accept(ModItems.ECHO_HELMET.get());
                        out.accept(ModItems.ECHO_CHESTPLATE.get());
                        out.accept(ModItems.ECHO_LEGGINGS.get());
                        out.accept(ModItems.ECHO_BOOTS.get());
                        out.accept(ModItems.RIFT_WAND.get());
                        out.accept(ModBlocks.SCORCHITE_ORE.get());
                        out.accept(ModBlocks.UMBRALITE_ORE.get());
                        out.accept(ModBlocks.LUMINA_ORE.get());
                        out.accept(ModBlocks.RESONITE_BLOCK.get());
                        out.accept(ModBlocks.RESONANCE_FORGE.get());
                        out.accept(ModItems.SCORCHITE_SHARD.get());
                        out.accept(ModItems.UMBRALITE_CHUNK.get());
                        out.accept(ModItems.LUMINA_GEM.get());
                        out.accept(ModItems.RESONITE_INGOT.get());
                        out.accept(ModItems.RESONITE_TEMPLATE.get());
                        out.accept(ModItems.RESONITE_SWORD.get());
                        out.accept(ModItems.RESONITE_PICKAXE.get());
                        out.accept(ModItems.RESONITE_AXE.get());
                        out.accept(ModItems.RESONITE_SHOVEL.get());
                        out.accept(ModItems.RESONITE_HOE.get());
                        out.accept(ModItems.RESONITE_HELMET.get());
                        out.accept(ModItems.RESONITE_CHESTPLATE.get());
                        out.accept(ModItems.RESONITE_LEGGINGS.get());
                        out.accept(ModItems.RESONITE_BOOTS.get());
                        out.accept(ModBlocks.ECHO_JELLY.get());
                        out.accept(ModBlocks.ECHO_LAMP.get());
                        out.accept(ModBlocks.ECHO_GLASS.get());
                        out.accept(ModItems.STARDUST.get());
                        out.accept(ModBlocks.ARENA_CORE.get());
                        out.accept(ModItems.ECHO_BLOOM_SEEDS.get());
                        out.accept(ModItems.ECHO_BLOOM_FLOWER.get());
                        out.accept(ModItems.ELIXIR_SIGHT.get());
                        out.accept(ModItems.ELIXIR_STARSTEP.get());
                        out.accept(ModItems.ELIXIR_RESONANCE.get());
                        out.accept(ModBlocks.ECHO_GATE.get());
                        out.accept(ModBlocks.ECHO_DETECTOR.get());
                        out.accept(ModBlocks.ECHO_PULSER.get());
                        out.accept(ModBlocks.ECHO_TRANSMITTER.get());
                        out.accept(ModBlocks.ECHO_RECEIVER.get());
                        out.accept(ModBlocks.ECHO_LAUNCHER.get());
                        out.accept(ModItems.ECHO_DRIFTER_SPAWN_EGG.get());
                        out.accept(ModItems.ECHO_GUARDIAN_SPAWN_EGG.get());
                        out.accept(ModItems.ECHO_VILLAGER_SPAWN_EGG.get());
                        // Яйца
                        out.accept(ModItems.SHARDLING_SPAWN_EGG.get());
                        out.accept(ModItems.HOLLOW_STALKER_SPAWN_EGG.get());
                        out.accept(ModItems.GLOW_PUFF_SPAWN_EGG.get());
                        out.accept(ModItems.ECHO_SOVEREIGN_SPAWN_EGG.get());
                    })
                    .build());
}
