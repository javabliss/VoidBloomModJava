package com.voidbloom.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Эхо-пусковая плита: подбрасывает вверх, сила зависит от уровня редстоун-сигнала (0–15). Shift отключает. */
public class EchoLauncherBlock extends Block {
    public static final MapCodec<EchoLauncherBlock> CODEC = simpleCodec(EchoLauncherBlock::new);
    private static final VoxelShape SHAPE = Block.box(0, 0, 0, 16, 4, 16);

    public EchoLauncherBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    public void fallOn(Level level, BlockState state, BlockPos pos, Entity entity, float distance) {
        entity.causeFallDamage(distance, 0.0F, level.damageSources().fall());
    }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        if (entity.isSteppingCarefully()) return;
        int power = level.getBestNeighborSignal(pos);
        Vec3 v = entity.getDeltaMovement();
        entity.setDeltaMovement(v.x, 0.8D + power * 0.11D, v.z);
        entity.hurtMarked = true;
        entity.resetFallDistance();
        if (!level.isClientSide) level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.BLOCKS, 0.8F, 1.4F);
        super.stepOn(level, pos, state, entity);
    }
}
