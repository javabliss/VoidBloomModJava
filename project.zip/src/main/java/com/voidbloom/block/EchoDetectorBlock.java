package com.voidbloom.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.AABB;

/** Эхо-детектор: выдаёт сигнал 1–15, чем ближе живое существо (радиус 7 блоков), тем сильнее. */
public class EchoDetectorBlock extends Block {
    public static final MapCodec<EchoDetectorBlock> CODEC = simpleCodec(EchoDetectorBlock::new);
    public static final IntegerProperty POWER = BlockStateProperties.POWER;

    public EchoDetectorBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(POWER, 0));
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(POWER);
    }

    @Override
    protected boolean isSignalSource(BlockState state) {
        return true;
    }

    @Override
    protected int getSignal(BlockState state, BlockGetter level, BlockPos pos, Direction dir) {
        return state.getValue(POWER);
    }

    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moved) {
        if (!level.isClientSide && !old.is(state.getBlock())) level.scheduleTick(pos, this, 10);
    }

    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        double best = 99.0D;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(pos).inflate(7.0D))) {
            best = Math.min(best, Math.sqrt(e.distanceToSqr(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D)));
        }
        int power = best > 7.0D ? 0 : Math.max(1, 15 - (int) (best * 2.0D));
        if (power != state.getValue(POWER)) {
            level.setBlock(pos, state.setValue(POWER, power), 3);
            level.updateNeighborsAt(pos, this);
        }
        level.scheduleTick(pos, this, 10);
    }
}
