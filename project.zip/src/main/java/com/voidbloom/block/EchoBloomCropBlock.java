package com.voidbloom.block;

import com.voidbloom.registry.ModBlocks;
import com.voidbloom.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Эхо-бутон: растёт на эхо-почве, эхо-мхе и грядках. */
public class EchoBloomCropBlock extends CropBlock {
    public EchoBloomCropBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected ItemLike getBaseSeedId() {
        return ModItems.ECHO_BLOOM_SEEDS.get();
    }

    @Override
    protected boolean mayPlaceOn(BlockState state, BlockGetter level, BlockPos pos) {
        return state.is(ModBlocks.ECHO_SOIL.get()) || state.is(ModBlocks.ECHO_MOSS.get()) || state.is(Blocks.FARMLAND);
    }
}
