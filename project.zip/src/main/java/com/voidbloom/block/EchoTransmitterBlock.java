package com.voidbloom.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.Block;

public class EchoTransmitterBlock extends EchoWirelessBlock {
    public static final MapCodec<EchoTransmitterBlock> CODEC = simpleCodec(EchoTransmitterBlock::new);

    public EchoTransmitterBlock(Properties properties) {
        super(properties, false);
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }
}
