package com.voidbloom.block;

import com.mojang.serialization.MapCodec;
import com.voidbloom.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

/** Часть собранного Горна резонанса: 27 клеток куба 3x3x3 выглядят как один большой блок. */
public class ResonanceHullBlock extends Block {
    public static final MapCodec<ResonanceHullBlock> CODEC = simpleCodec(ResonanceHullBlock::new);
    public static final IntegerProperty CX = IntegerProperty.create("cx", 0, 2);
    public static final IntegerProperty CY = IntegerProperty.create("cy", 0, 2);
    public static final IntegerProperty CZ = IntegerProperty.create("cz", 0, 2);

    public ResonanceHullBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(CX, 0).setValue(CY, 0).setValue(CZ, 0));
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(CX, CY, CZ);
    }

    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
        if (!level.isClientSide && !state.is(newState.getBlock()) && !ResonanceForgeBlock.busy) {
            BlockPos center = pos.offset(1 - state.getValue(CX), 1 - state.getValue(CY), 1 - state.getValue(CZ));
            ResonanceForgeBlock.disassemble(level, center, pos);
        }
        super.onRemove(state, level, pos, newState, moved);
    }

    @Override
    public ItemStack getCloneItemStack(LevelReader level, BlockPos pos, BlockState state) {
        return new ItemStack(ModBlocks.ECHO_BRICKS.get());
    }
}
