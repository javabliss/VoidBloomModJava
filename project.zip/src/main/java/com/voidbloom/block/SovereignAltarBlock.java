package com.voidbloom.block;

import com.mojang.serialization.MapCodec;
import com.voidbloom.entity.EchoSovereignEntity;
import com.voidbloom.registry.ModBlocks;
import com.voidbloom.registry.ModEntities;
import com.voidbloom.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Алтарь Повелителя: ПКМ тремя эхо-кристаллами вызывает босса. После вызова алтарь гаснет. */
public class SovereignAltarBlock extends Block {
    public static final MapCodec<SovereignAltarBlock> CODEC = simpleCodec(SovereignAltarBlock::new);
    private static final int COST = 3;

    public SovereignAltarBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        if (!stack.is(ModItems.ECHO_CRYSTAL.get()) || stack.getCount() < COST) {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (level.isClientSide) {
            return ItemInteractionResult.SUCCESS;
        }
        if (level.getDifficulty() == Difficulty.PEACEFUL) {
            player.displayClientMessage(Component.translatable("message.voidbloom.altar_peaceful"), true);
            return ItemInteractionResult.CONSUME;
        }
        ServerLevel server = (ServerLevel) level;
        if (!player.getAbilities().instabuild) {
            stack.shrink(COST);
        }

        EchoSovereignEntity boss = ModEntities.ECHO_SOVEREIGN.get().create(server);
        if (boss != null) {
            boss.moveTo(pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D, player.getYRot() + 180.0F, 0.0F);
            boss.finalizeSpawn(server, server.getCurrentDifficultyAt(pos), MobSpawnType.TRIGGERED, null);
            server.addFreshEntity(boss);
        }
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(server);
        if (bolt != null) {
            bolt.moveTo(pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D);
            bolt.setVisualOnly(true);
            server.addFreshEntity(bolt);
        }
        server.playSound(null, pos, SoundEvents.WARDEN_EMERGE, SoundSource.HOSTILE, 2.0F, 0.7F);
        server.setBlock(pos, ModBlocks.ECHO_STONE.get().defaultBlockState(), 3);
        return ItemInteractionResult.CONSUME;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hit) {
        if (!level.isClientSide) {
            player.displayClientMessage(Component.translatable("message.voidbloom.altar_hint"), true);
        }
        return InteractionResult.SUCCESS;
    }
}
