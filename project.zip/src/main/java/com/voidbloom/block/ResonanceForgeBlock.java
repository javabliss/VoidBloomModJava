package com.voidbloom.block;

import com.mojang.serialization.MapCodec;
import com.voidbloom.registry.ModBlockEntities;
import com.voidbloom.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Горн резонанса — контроллер мультиблока с интерфейсом (как варочная стойка).
 * Схема: куб 3x3x3 из эхо-кирпичей, в центре магма-блок, горн — вместо кирпича в середине боковой стороны среднего слоя.
 */
public class ResonanceForgeBlock extends Block implements EntityBlock {
    public static final MapCodec<ResonanceForgeBlock> CODEC = simpleCodec(ResonanceForgeBlock::new);

    public ResonanceForgeBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    /**
     * Куб 3x3x3 из эхо-кирпичей: в середине магма-блок, а горн заменяет один из кирпичей
     * в середине любой боковой стороны среднего слоя. Возвращает наименьшее число ошибок
     * среди четырёх возможных положений горна.
     */
    public static int countMistakes(Level level, BlockPos core) {
        int best = Integer.MAX_VALUE;
        for (net.minecraft.core.Direction dir : net.minecraft.core.Direction.Plane.HORIZONTAL) {
            BlockPos center = core.relative(dir);
            int bad = 0;
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        BlockPos p = center.offset(dx, dy, dz);
                        if (p.equals(core)) continue;
                        Block want = (dx == 0 && dy == 0 && dz == 0) ? Blocks.MAGMA_BLOCK : ModBlocks.ECHO_BRICKS.get();
                        if (!level.getBlockState(p).is(want)) bad++;
                    }
                }
            }
            best = Math.min(best, bad);
        }
        return best;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        int bad = countMistakes(level, pos);
        if (bad > 0) {
            player.displayClientMessage(Component.translatable("message.voidbloom.forge_bad", bad), true);
            return InteractionResult.CONSUME;
        }
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof ResonanceForgeBlockEntity forge && player instanceof ServerPlayer sp) {
            forge.recheck();
            sp.openMenu(forge, pos);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ResonanceForgeBlockEntity(pos, state);
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide || type != ModBlockEntities.RESONANCE_FORGE.get()) return null;
        return (BlockEntityTicker<T>) (BlockEntityTicker<ResonanceForgeBlockEntity>) ResonanceForgeBlockEntity::tick;
    }

    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock())) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof ResonanceForgeBlockEntity forge) {
                Containers.dropContents(level, pos, forge);
            }
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }
}
