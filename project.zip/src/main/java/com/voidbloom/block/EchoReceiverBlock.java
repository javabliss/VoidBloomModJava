package com.voidbloom.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.Block;

public class EchoReceiverBlock extends EchoWirelessBlock {
    public static final MapCodec<EchoReceiverBlock> CODEC = simpleCodec(EchoReceiverBlock::new);

    public EchoReceiverBlock(Properties properties) {
        super(properties, true);
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }
}
