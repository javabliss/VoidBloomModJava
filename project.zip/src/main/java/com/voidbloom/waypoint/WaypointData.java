package com.voidbloom.waypoint;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Хранилище всех эхо-врат мира: владелец, измерение, позиция, имя. */
public class WaypointData extends SavedData {
    public static final class Gate {
        public final UUID owner;
        public final ResourceKey<Level> dim;
        public final BlockPos pos;
        public String name;

        public Gate(UUID owner, ResourceKey<Level> dim, BlockPos pos, String name) {
            this.owner = owner;
            this.dim = dim;
            this.pos = pos;
            this.name = name;
        }
    }

    private final List<Gate> gates = new ArrayList<>();

    public static WaypointData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(
                new SavedData.Factory<>(WaypointData::new, WaypointData::load, null), "voidbloom_waypoints");
    }

    public static WaypointData load(CompoundTag tag, HolderLookup.Provider registries) {
        WaypointData data = new WaypointData();
        ListTag list = tag.getList("gates", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            try {
                data.gates.add(new Gate(UUID.fromString(t.getString("owner")),
                        ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(t.getString("dim"))),
                        BlockPos.of(t.getLong("pos")), t.getString("name")));
            } catch (RuntimeException ignored) {
            }
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        for (Gate g : gates) {
            CompoundTag t = new CompoundTag();
            t.putString("owner", g.owner.toString());
            t.putString("dim", g.dim.location().toString());
            t.putLong("pos", g.pos.asLong());
            t.putString("name", g.name);
            list.add(t);
        }
        tag.put("gates", list);
        return tag;
    }

    public List<Gate> of(UUID owner) {
        List<Gate> result = new ArrayList<>();
        for (Gate g : gates) if (g.owner.equals(owner)) result.add(g);
        return result;
    }

    public Gate find(ResourceKey<Level> dim, BlockPos pos) {
        for (Gate g : gates) if (g.dim.equals(dim) && g.pos.equals(pos)) return g;
        return null;
    }

    public Gate add(UUID owner, ResourceKey<Level> dim, BlockPos pos) {
        Gate existing = find(dim, pos);
        if (existing != null) return existing;
        int n = 1;
        while (nameTaken(owner, "Врата " + n, null)) n++;
        Gate g = new Gate(owner, dim, pos.immutable(), "Врата " + n);
        gates.add(g);
        setDirty();
        return g;
    }

    public void remove(ResourceKey<Level> dim, BlockPos pos) {
        if (gates.removeIf(g -> g.dim.equals(dim) && g.pos.equals(pos))) setDirty();
    }

    public boolean nameTaken(UUID owner, String name, Gate except) {
        for (Gate g : gates) {
            if (g != except && g.owner.equals(owner) && g.name.equalsIgnoreCase(name)) return true;
        }
        return false;
    }

    /** @return false, если имя пустое или уже занято. */
    public boolean rename(Gate gate, String name) {
        String n = name.trim();
        if (n.isEmpty() || n.length() > 24 || nameTaken(gate.owner, n, gate)) return false;
        gate.name = n;
        setDirty();
        return true;
    }
}
