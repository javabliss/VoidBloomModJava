package com.voidbloom.waypoint;

import com.voidbloom.block.EchoGateBlock;
import com.voidbloom.net.GatePayloads;
import com.voidbloom.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/** Серверная логика эхо-врат: список, переименование, телепорт. */
public class GateService {
    public static void sendOpen(ServerPlayer player, BlockPos lowerPos) {
        WaypointData data = WaypointData.get(player.server);
        WaypointData.Gate gate = data.find(player.level().dimension(), lowerPos);
        if (gate == null) gate = data.add(player.getUUID(), player.level().dimension(), lowerPos);
        send(player, lowerPos, gate);
    }

    private static void send(ServerPlayer player, BlockPos current, WaypointData.Gate gate) {
        WaypointData data = WaypointData.get(player.server);
        List<GatePayloads.Entry> list = new ArrayList<>();
        for (WaypointData.Gate g : data.of(gate.owner)) {
            list.add(new GatePayloads.Entry(g.pos, g.dim.location().toString(), g.name));
        }
        boolean canEdit = gate.owner.equals(player.getUUID()) || player.hasPermissions(2);
        PacketDistributor.sendToPlayer(player, new GatePayloads.Open(current, player.level().dimension().location().toString(), canEdit, list));
    }

    public static void handle(ServerPlayer player, GatePayloads.Action a) {
        WaypointData data = WaypointData.get(player.server);
        ResourceKey<Level> fromDim = player.level().dimension();
        BlockState fromState = player.level().getBlockState(a.from());
        WaypointData.Gate from = data.find(fromDim, a.from());
        if (from == null || !fromState.is(ModBlocks.ECHO_GATE.get())
                || player.distanceToSqr(a.from().getX() + 0.5, a.from().getY() + 0.5, a.from().getZ() + 0.5) > 64) return;
        ResourceKey<Level> dim;
        try {
            dim = ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(a.targetDim()));
        } catch (RuntimeException e) {
            return;
        }
        WaypointData.Gate target = data.find(dim, a.target());
        if (target == null || !target.owner.equals(from.owner)) return;

        if (a.action() == 0) {
            if (!(from.owner.equals(player.getUUID()) || player.hasPermissions(2))) return;
            if (!data.rename(target, a.name())) {
                player.displayClientMessage(Component.translatable("message.voidbloom.gate_name_taken"), true);
            } else {
                player.displayClientMessage(Component.translatable("message.voidbloom.gate_renamed", target.name), true);
            }
            send(player, a.from(), from);
        } else if (a.action() == 1) {
            teleport(player, data, from, target);
        }
    }

    private static void teleport(ServerPlayer player, WaypointData data, WaypointData.Gate from, WaypointData.Gate target) {
        ServerLevel level = player.server.getLevel(target.dim);
        if (level == null || target == from) return;
        BlockState state = level.getBlockState(target.pos);
        if (!state.is(ModBlocks.ECHO_GATE.get())) {
            data.remove(target.dim, target.pos);
            player.displayClientMessage(Component.translatable("message.voidbloom.gate_missing", target.name), true);
            send(player, from.pos, from);
            return;
        }
        Direction facing = state.getValue(EchoGateBlock.FACING);
        BlockPos stand = null;
        for (Direction d : new Direction[]{facing, facing.getOpposite(), facing.getClockWise(), facing.getCounterClockWise()}) {
            BlockPos p = target.pos.relative(d);
            if (free(level, p) && free(level, p.above()) && !free(level, p.below())) {
                stand = p;
                break;
            }
        }
        if (stand == null) stand = target.pos.relative(facing);
        player.level().playSound(null, player.blockPosition(), SoundEvents.PLAYER_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.0F);
        player.teleportTo(level, stand.getX() + 0.5, stand.getY(), stand.getZ() + 0.5, facing.toYRot(), 0.0F);
        player.resetFallDistance();
        level.playSound(null, stand, SoundEvents.PLAYER_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.0F);
        player.displayClientMessage(Component.translatable("message.voidbloom.gate_teleported", target.name), true);
    }

    private static boolean free(ServerLevel level, BlockPos p) {
        return level.getBlockState(p).getCollisionShape(level, p).isEmpty();
    }
}
