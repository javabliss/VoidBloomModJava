package com.voidbloom.net;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.client.ClientHooks;
import com.voidbloom.waypoint.GateService;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

@EventBusSubscriber(modid = VoidbloomMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public class ModNetwork {
    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToClient(GatePayloads.Open.TYPE, GatePayloads.Open.CODEC,
                (payload, ctx) -> ClientHooks.openGateScreen(payload));
        registrar.playToServer(GatePayloads.Action.TYPE, GatePayloads.Action.CODEC,
                (payload, ctx) -> {
                    if (ctx.player() instanceof ServerPlayer sp) GateService.handle(sp, payload);
                });
    }
}
