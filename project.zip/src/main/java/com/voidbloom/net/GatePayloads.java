package com.voidbloom.net;

import com.voidbloom.VoidbloomMod;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import java.util.ArrayList;
import java.util.List;

public class GatePayloads {
    public record Entry(BlockPos pos, String dim, String name) {}

    /** Сервер -> клиент: открыть/обновить экран врат. */
    public record Open(BlockPos current, String dim, boolean canEdit, List<Entry> gates) implements CustomPacketPayload {
        public static final Type<Open> TYPE = new Type<>(VoidbloomMod.id("gate_open"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Open> CODEC = StreamCodec.of(Open::write, Open::read);

        private static void write(RegistryFriendlyByteBuf buf, Open p) {
            buf.writeBlockPos(p.current);
            buf.writeUtf(p.dim);
            buf.writeBoolean(p.canEdit);
            buf.writeVarInt(p.gates.size());
            for (Entry e : p.gates) {
                buf.writeBlockPos(e.pos);
                buf.writeUtf(e.dim);
                buf.writeUtf(e.name, 64);
            }
        }

        private static Open read(RegistryFriendlyByteBuf buf) {
            BlockPos cur = buf.readBlockPos();
            String dim = buf.readUtf();
            boolean edit = buf.readBoolean();
            int n = buf.readVarInt();
            List<Entry> list = new ArrayList<>();
            for (int i = 0; i < n; i++) list.add(new Entry(buf.readBlockPos(), buf.readUtf(), buf.readUtf(64)));
            return new Open(cur, dim, edit, list);
        }

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Клиент -> сервер: переименовать (0) или телепортироваться (1). */
    public record Action(int action, BlockPos from, BlockPos target, String targetDim, String name) implements CustomPacketPayload {
        public static final Type<Action> TYPE = new Type<>(VoidbloomMod.id("gate_action"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Action> CODEC = StreamCodec.of(Action::write, Action::read);

        private static void write(RegistryFriendlyByteBuf buf, Action p) {
            buf.writeVarInt(p.action);
            buf.writeBlockPos(p.from);
            buf.writeBlockPos(p.target);
            buf.writeUtf(p.targetDim);
            buf.writeUtf(p.name, 64);
        }

        private static Action read(RegistryFriendlyByteBuf buf) {
            return new Action(buf.readVarInt(), buf.readBlockPos(), buf.readBlockPos(), buf.readUtf(), buf.readUtf(64));
        }

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }
}
