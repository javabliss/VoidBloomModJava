package com.voidbloom.event;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.registry.ModBlocks;
import com.voidbloom.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.Tags;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Приключенческие механики: приёмы оружия, валка леса, жильная добыча, бонус резонита. */
@EventBusSubscriber(modid = VoidbloomMod.MODID)
public class AdventureEvents {
    private static boolean busy = false;

    private static void drop(ServerLevel level, double x, double y, double z, ItemStack stack) {
        ItemEntity e = new ItemEntity(level, x, y, z, stack);
        e.setGlowingTag(true);
        e.setDeltaMovement(0, 0.2D, 0);
        level.addFreshEntity(e);
    }

    // ---------- приёмы оружия ----------
    @SubscribeEvent
    public static void weapons(LivingDamageEvent.Post event) {
        if (!(event.getSource().getEntity() instanceof Player p) || p.level().isClientSide || busy) return;
        LivingEntity target = event.getEntity();
        ItemStack weapon = p.getMainHandItem();
        if (weapon.is(ModItems.ECHO_SWORD.get())) {
            int combo = p.getPersistentData().getInt("vb_combo") + 1;
            if (combo >= 4) {
                combo = 0;
                ServerLevel level = (ServerLevel) p.level();
                busy = true;
                try {
                    List<LivingEntity> victims = level.getEntitiesOfClass(LivingEntity.class, target.getBoundingBox().inflate(4.0D),
                            e -> e != p && e != target && e.isAlive());
                    for (LivingEntity v : victims) v.hurt(p.damageSources().playerAttack(p), 5.0F);
                } finally {
                    busy = false;
                }
                level.sendParticles(ParticleTypes.SONIC_BOOM, target.getX(), target.getY() + 1.0D, target.getZ(), 1, 0, 0, 0, 0);
                level.playSound(null, target.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 2.0F, 0.5F);
            }
            p.getPersistentData().putInt("vb_combo", combo);
        } else if (weapon.is(ModItems.RESONITE_SWORD.get())) {
            p.heal(event.getNewDamage() * 0.15F);
            target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0, false, false));
        }
    }

    // ---------- валка леса и жильная добыча ----------
    @SubscribeEvent
    public static void breakBlock(BlockEvent.BreakEvent event) {
        if (busy || !(event.getPlayer() instanceof ServerPlayer p) || !(event.getLevel() instanceof ServerLevel level)) return;
        ItemStack tool = p.getMainHandItem();
        BlockState state = event.getState();
        BlockPos start = event.getPos();
        int limit = 0;
        boolean logs = false;
        if ((tool.is(ModItems.ECHO_AXE.get()) || tool.is(ModItems.RESONITE_AXE.get())) && state.is(BlockTags.LOGS)) {
            limit = tool.is(ModItems.RESONITE_AXE.get()) ? 96 : 48;
            logs = true;
        } else if (p.isShiftKeyDown() && (tool.is(ModItems.ECHO_PICKAXE.get()) || tool.is(ModItems.RESONITE_PICKAXE.get()))
                && (state.is(Tags.Blocks.ORES) || state.is(ModBlocks.ECHO_CRYSTAL_ORE.get()) || state.is(ModBlocks.LUMINA_ORE.get())
                || state.is(ModBlocks.SCORCHITE_ORE.get()) || state.is(ModBlocks.UMBRALITE_ORE.get()))) {
            limit = tool.is(ModItems.RESONITE_PICKAXE.get()) ? 32 : 12;
        }
        if (limit == 0) return;

        Set<BlockPos> seen = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        List<BlockPos> found = new ArrayList<>();
        seen.add(start);
        queue.add(start);
        while (!queue.isEmpty() && found.size() < limit) {
            BlockPos cur = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        BlockPos n = cur.offset(dx, dy, dz);
                        if (!seen.add(n) || found.size() >= limit) continue;
                        BlockState ns = level.getBlockState(n);
                        boolean match = logs ? ns.is(BlockTags.LOGS) : ns.is(state.getBlock());
                        if (match) {
                            found.add(n);
                            queue.add(n);
                        }
                    }
                }
            }
        }
        busy = true;
        try {
            for (BlockPos bp : found) {
                if (tool.isEmpty()) break;
                level.destroyBlock(bp, true, p);
                tool.hurtAndBreak(1, p, EquipmentSlot.MAINHAND);
            }
        } finally {
            busy = false;
        }
    }

    // ---------- бонус полного резонитового комплекта ----------
    @SubscribeEvent
    public static void resoniteSet(PlayerTickEvent.Post event) {
        Player p = event.getEntity();
        if (p.level().isClientSide || p.tickCount % 40 != 0) return;
        if (isItem(p, EquipmentSlot.HEAD, ModItems.RESONITE_HELMET.get()) && isItem(p, EquipmentSlot.CHEST, ModItems.RESONITE_CHESTPLATE.get())
                && isItem(p, EquipmentSlot.LEGS, ModItems.RESONITE_LEGGINGS.get()) && isItem(p, EquipmentSlot.FEET, ModItems.RESONITE_BOOTS.get())) {
            p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 100, 0, true, false));
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 0, true, false));
        }
    }

    private static boolean isItem(Player p, EquipmentSlot slot, Item item) {
        return p.getItemBySlot(slot).is(item);
    }
}
