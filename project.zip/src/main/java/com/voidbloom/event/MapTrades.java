package com.voidbloom.event;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.entity.npc.VillagerTrades;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.saveddata.maps.MapDecorationType;
import net.minecraft.world.level.saveddata.maps.MapDecorationTypes;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.village.VillagerTradesEvent;

import java.util.Optional;

/** Картограф (в т.ч. эхо-житель) продаёт карты к структурам Бездны Эха, как ванильные карты клада. */
@EventBusSubscriber(modid = VoidbloomMod.MODID)
public class MapTrades {
    @SubscribeEvent
    public static void trades(VillagerTradesEvent event) {
        if (event.getType() != VillagerProfession.CARTOGRAPHER) return;
        var t = event.getTrades();
        t.get(1).add(new MapListing("ruins", MapDecorationTypes.RED_X, 4, 8));
        t.get(1).add(new MapListing("camp", MapDecorationTypes.TARGET_X, 4, 8));
        t.get(1).add(new MapListing("obelisk", MapDecorationTypes.TARGET_POINT, 6, 8));
        t.get(2).add(new MapListing("vault", MapDecorationTypes.TRIAL_CHAMBERS, 8, 12));
        t.get(2).add(new MapListing("arena", MapDecorationTypes.MONUMENT, 8, 12));
        t.get(3).add(new MapListing("sanctum", MapDecorationTypes.MANSION, 12, 16));
    }

    public record MapListing(String target, Holder<MapDecorationType> decoration, int cost, int xp) implements VillagerTrades.ItemListing {
        @Override
        public MerchantOffer getOffer(Entity trader, RandomSource random) {
            if (!(trader.level() instanceof ServerLevel level) || level.dimension() != VoidbloomMod.ECHO_EXPANSE) return null;
            TagKey<Structure> tag = TagKey.create(Registries.STRUCTURE, VoidbloomMod.id("map_" + target));
            BlockPos pos = level.findNearestMapStructure(tag, trader.blockPosition(), 100, true);
            if (pos == null) return null;
            ItemStack map = MapItem.create(level, pos.getX(), pos.getZ(), (byte) 2, true, true);
            MapItem.renderBiomePreviewMap(level, map);
            MapItemSavedData.addTargetDecoration(map, pos, "+", decoration);
            map.set(DataComponents.ITEM_NAME, Component.translatable("item.voidbloom.map_" + target));
            return new MerchantOffer(new ItemCost(ModItems.ECHO_CRYSTAL.get(), cost), Optional.of(new ItemCost(Items.COMPASS)),
                    map, 8, xp, 0.2F);
        }
    }
}
