package com.voidbloom.event;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.block.ResonanceForgeBlock;
import com.voidbloom.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.level.BlockEvent;

/** Последний поставленный блок куба (кирпич или магма) превращает его в цельный горн. */
@EventBusSubscriber(modid = VoidbloomMod.MODID)
public class ForgeEvents {
    @SubscribeEvent
    public static void placed(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        BlockState s = event.getPlacedBlock();
        if (!(s.is(ModBlocks.ECHO_BRICKS.get()) || s.is(Blocks.MAGMA_BLOCK))) return;
        BlockPos p = event.getPos();
        for (BlockPos q : BlockPos.betweenClosed(p.offset(-2, -2, -2), p.offset(2, 2, 2))) {
            if (level.getBlockState(q).is(ModBlocks.RESONANCE_FORGE.get()) && ResonanceForgeBlock.tryAssemble(level, q.immutable())) break;
        }
    }
}
