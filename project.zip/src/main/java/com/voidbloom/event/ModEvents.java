package com.voidbloom.event;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.block.PortalHelper;
import com.voidbloom.entity.EchoSovereignEntity;
import com.voidbloom.entity.GlowPuffEntity;
import com.voidbloom.entity.HollowStalkerEntity;
import com.voidbloom.entity.ShardlingEntity;
import com.voidbloom.registry.ModBlocks;
import com.voidbloom.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import com.voidbloom.registry.ModItems;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

public class ModEvents {

    @EventBusSubscriber(modid = VoidbloomMod.MODID, bus = EventBusSubscriber.Bus.MOD)
    public static class ModBus {
        @SubscribeEvent
        public static void attributes(EntityAttributeCreationEvent event) {
            event.put(ModEntities.SHARDLING.get(), ShardlingEntity.createAttributes().build());
            event.put(ModEntities.HOLLOW_STALKER.get(), HollowStalkerEntity.createAttributes().build());
            event.put(ModEntities.GLOW_PUFF.get(), GlowPuffEntity.createAttributes().build());
            event.put(ModEntities.ECHO_SOVEREIGN.get(), EchoSovereignEntity.createAttributes().build());
            event.put(ModEntities.ECHO_DRIFTER.get(), com.voidbloom.entity.EchoDrifterEntity.createAttributes().build());
            event.put(ModEntities.ECHO_GUARDIAN.get(), com.voidbloom.entity.EchoGuardianEntity.createAttributes().build());
            event.put(ModEntities.ECHO_VILLAGER.get(), net.minecraft.world.entity.npc.Villager.createAttributes().build());
        }

        @SubscribeEvent
        public static void spawnPlacements(RegisterSpawnPlacementsEvent event) {
            event.register(ModEntities.SHARDLING.get(), SpawnPlacementTypes.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkAnyLightMonsterSpawnRules,
                    RegisterSpawnPlacementsEvent.Operation.OR);
            event.register(ModEntities.HOLLOW_STALKER.get(), SpawnPlacementTypes.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkAnyLightMonsterSpawnRules,
                    RegisterSpawnPlacementsEvent.Operation.OR);
            event.register(ModEntities.ECHO_DRIFTER.get(), SpawnPlacementTypes.NO_RESTRICTIONS,
                    Heightmap.Types.MOTION_BLOCKING,
                    (type, lvl, reason, pos, rand) -> lvl.getBlockState(pos).isAir(),
                    RegisterSpawnPlacementsEvent.Operation.OR);
            event.register(ModEntities.GLOW_PUFF.get(), SpawnPlacementTypes.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules,
                    RegisterSpawnPlacementsEvent.Operation.OR);
        }
    }

    @EventBusSubscriber(modid = VoidbloomMod.MODID)
    public static class GameBus {

        private static boolean fullSet(Player p) {
            return p.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.ECHO_HELMET.get())
                    && p.getItemBySlot(EquipmentSlot.CHEST).is(ModItems.ECHO_CHESTPLATE.get())
                    && p.getItemBySlot(EquipmentSlot.LEGS).is(ModItems.ECHO_LEGGINGS.get())
                    && p.getItemBySlot(EquipmentSlot.FEET).is(ModItems.ECHO_BOOTS.get());
        }

        /** Бонус полного набора: прыгучесть, в Бездне ещё и ночное зрение. */
        @SubscribeEvent
        public static void setBonus(PlayerTickEvent.Post event) {
            Player p = event.getEntity();
            if (p.level().isClientSide || p.tickCount % 40 != 0 || !fullSet(p)) return;
            p.addEffect(new MobEffectInstance(MobEffects.JUMP, 100, 1, true, false));
            if (p.level().dimension() == VoidbloomMod.ECHO_EXPANSE)
                p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 320, 0, true, false));
        }

        @SubscribeEvent
        public static void softFall(LivingFallEvent event) {
            if (event.getEntity() instanceof Player p && fullSet(p)) event.setDamageMultiplier(event.getDamageMultiplier() * 0.4F);
        }

        /** Зажигание портала: ПКМ осколком эха по блоку рамки. */
        @SubscribeEvent
        public static void lightPortal(PlayerInteractEvent.RightClickBlock event) {
            Level level = event.getLevel();
            if (level.isClientSide) return;
            ItemStack held = event.getItemStack();
            if (!held.is(Items.ECHO_SHARD)) return;
            if (!level.getBlockState(event.getPos()).is(ModBlocks.RIFT_FRAME.get())) return;
            if (event.getFace() == null) return;

            BlockPos start = event.getPos().relative(event.getFace());
            if (PortalHelper.tryLight(level, start)) {
                level.playSound(null, start, SoundEvents.RESPAWN_ANCHOR_CHARGE, SoundSource.BLOCKS, 1.0F, 0.7F);
                if (!event.getEntity().getAbilities().instabuild) {
                    held.shrink(1);
                }
                event.setCanceled(true);
            }
        }
    }
}
